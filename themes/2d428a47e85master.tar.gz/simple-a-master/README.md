simple-a
========

Minimalistic Hugo theme

![Screenshot](https://raw.githubusercontent.com/AlexFinn/simple-a/master/images/screenshot.png)
[Demo](https://simple-a.alxschwarz.com)
